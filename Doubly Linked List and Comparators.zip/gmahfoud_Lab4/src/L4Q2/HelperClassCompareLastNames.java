package L4Q2;

import java.util.Comparator;

public class HelperClassCompareLastNames implements Comparator<Student> {
    //Helper class to compare last names in ascending order

    @Override
    public int compare(Student o1, Student o2) {
        return o1.getLastName().compareTo(o2.getLastName());
    }
}
