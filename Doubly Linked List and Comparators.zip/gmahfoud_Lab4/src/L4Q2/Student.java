package L4Q2;

public class Student implements Comparable<Student> {
    //Variable declaration
    private Double score;
    private String firstName;
    private String lastName;
    //Parametrized constructor
    public Student(String firstName, String lastName, Double score){
        this.firstName = firstName;
        this.lastName = lastName;
        this.score = score;
    }
    //Empty constructor
    public Student(){
        firstName = "Gus";
        lastName = "Mahfoud";
        score = 100.0;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    //toString method to format the items in the ArrayList
    @Override
    public String toString() {
        return getFirstName() + " " + getLastName() + ": " + getScore();
    }

    //compareTo method to compare the scores in ascending order
    @Override
    public int compareTo(Student s) {
        return Double.compare(getScore(), s.getScore());
    }
}
