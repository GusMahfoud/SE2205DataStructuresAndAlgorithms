package L4Q2;

import java.util.*;

public class DriverForStudentClass {
    //MyHeader method
    public static void MyHeader(int labE_number, int q_number){
        System.out.println("===================================================================");
        System.out.println("Lab Exercise " + labE_number + "-Q" + q_number);
        System.out.println("Prepared By: Ghasan Mahfoud");
        System.out.println("Student Number: 251280405");
        System.out.println("Goal Of This Exercise: Using Comparable and Comparator!");
        System.out.println("===================================================================");
    }
    //MyFooter method
    public static void MyFooter(int labE_number, int q_number){
        // \n to ensure the footer appears after the output
        System.out.println("\n===================================================================");
        System.out.println("Completion of Lab Exercise " + labE_number + "-Q" + q_number + " is successful!");
        System.out.println("Signing off - Gus");
        System.out.println("===================================================================");
    }
    public static void main(String[] args) {
        MyHeader(4,2);

        //Creating a new ArrayList of type Student
        ArrayList<Student> studentList = new ArrayList<>();
        //Adding to the array list
        studentList.add(new Student());
        studentList.add(new Student("Harry", "Potter", 75.5));
        studentList.add(new Student("Ronald", "Weasley", 86.0));
        studentList.add(new Student("Hermione", "Granger", 91.7));
        studentList.add(new Student("Parvati", "Patil", 93.75));

        //Printing the arraylist
        System.out.println("Original Score Card: ");
        System.out.println(studentList);

        //Sorting and printing the arraylist in descending order
        Collections.sort(studentList, new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                return o2.compareTo(o1);
            }
        });
        System.out.println("\nScore card sorted by scores (Descending): ");
        System.out.println(studentList);

        //Sorting and printing the arraylist based on last names
        Collections.sort(studentList, new HelperClassCompareLastNames());
        System.out.println("\nScore card sorted by last names: ");
        System.out.println(studentList);

        //Sorting and printing the arraylist based on first names
        Collections.sort(studentList, new HelperClassCompareFirstNames());
        System.out.println("\nScore card sorted by first names: ");
        System.out.println(studentList);
        MyFooter(4,2);
    }
}
