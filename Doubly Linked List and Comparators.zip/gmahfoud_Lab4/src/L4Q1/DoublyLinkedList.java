package L4Q1;
import java.util.ArrayList;

public class DoublyLinkedList<E>{
    //Nested Node class
    public static class Node<E> {
        private E element;
        private Node<E> prev;
        private Node<E> next;


        //Node constructor
        public Node(E element, Node<E> prev, Node<E> next){
            this.element = element;
            this.prev = prev;
            this.next = next;
        }

        public Node<E> getNext() {
            return next;
        }

        public void setNext(Node<E> next) {
            this.next = next;
        }

        public Node<E> getPrev() {
            return prev;
        }

        public void setPrev(Node<E> prev) {
            this.prev = prev;
        }

        public E getElement() {
            return element;
        }
    }
    //Creating the header and trailer for the list
    private Node<E> header;
    private Node<E> trailer;
    private int size = 0;
    //Constructor foe DoublyLinkedList
    public DoublyLinkedList(){
        header = new Node<>(null,null,null);
        trailer = new Node<>(null,header,null);
        header.setNext(trailer);
    }

    //AddLast method that adds a node 'E' at the end of the list
    public void addLast(E e){
        addBetween(e, trailer.getPrev(), trailer);
    }

    //addBetween method that adds a node in between a predecessor and a successor
    public void addBetween(E e, Node<E> predecessor, Node<E> successor){
        //Creates a new node called newest
        Node<E> newest = new Node<>(e, predecessor, successor);
        //Sets the predecessors 'next' link to the new node
        predecessor.setNext(newest);
        //Sets the successors 'prev' link to the new node
        successor.setPrev(newest);
        //Increasing the size of the list
        size++;
    }
    //Method that checks if the list is empty
    public boolean isEmpty(){
        return size == 0;
    }
    //Method that returns size
    public int size(){
        return size;
    }
    //Creates a temporary node 'current' designed for iterating through the linkedlist until the node that we want is equal to the temp node.
    public Node<E> findNode(E e){
        //Starts at the beginning of the list and uses a while loop to work forwards until the node we want is found
        Node<E> current = header.getNext();
        while (current != trailer){
            if (current.getElement() == e){
                return current;
            }
            current = current.getNext();
        }
        //Returns null if the node is not found
        return null;
    }


    //toString method to print the DoublyLinkedList
    @Override
    public String toString() {
        ArrayList<E> list = new ArrayList<>(size());
        Node<E> current = header.getNext();

        while (current != trailer){
            list.add(current.getElement());
             current = current.getNext();
        }
        return list.toString();
    }
}
