package L4Q1;

public class Driver_DoublyLinkedList {
    //MyHeader method
    public static void MyHeader(int labE_number, int q_number){
        System.out.println("===================================================================");
        System.out.println("Lab Exercise " + labE_number + "-Q" + q_number);
        System.out.println("Prepared By: Ghasan Mahfoud");
        System.out.println("Student Number: 251280405");
        System.out.println("Goal Of This Exercise: Using Doubly Linked Lists!");
        System.out.println("===================================================================");
    }
    //MyFooter method
    public static void MyFooter(int labE_number, int q_number){
        // \n to ensure the footer appears after the output
        System.out.println("\n===================================================================");
        System.out.println("Completion of Lab Exercise " + labE_number + "-Q" + q_number + " is successful!");
        System.out.println("Signing off - Gus");
        System.out.println("===================================================================");
    }

    public static void main(String[] args) {
        MyHeader(4,1);
        //Creating a new DoublyLinkedList of type MyStudent
        DoublyLinkedList<MyStudent> gusList = new DoublyLinkedList<>();
        //Creating items to be added to the list
        MyStudent s0 = new MyStudent();
        MyStudent s1 = new MyStudent("Harry", 67.25);
        MyStudent s2 = new MyStudent("Luna", 87.5);
        MyStudent s3 = new MyStudent("Vincent", 60.5);
        MyStudent s4 = new MyStudent("Hermione", 89.2);
        //Adding items to the list
        gusList.addLast(s0);
        gusList.addLast(s1);
        gusList.addLast(s2);
        gusList.addLast(s3);
        //Printing the list
        System.out.println(gusList);

        //Creating 2 nodes called anyname1 and 2
        DoublyLinkedList.Node<MyStudent> anyName;
        DoublyLinkedList.Node<MyStudent> anyName2;
        //Setting the nodes equal to the third and fourth index in the list
        anyName = gusList.findNode(s2);
        anyName2 = gusList.findNode(s3);
        //Adding a node in between anyname and anyname2
        gusList.addBetween(s4, anyName, anyName2);
        //Printing the list
        System.out.println(gusList);

        MyFooter(4,1);
    }
}
