package L4Q1;

public class MyStudent {
    //Variable declaration
    private String firstName;
    private Double score;
    //Empty constructor for MyStudent class
    public MyStudent(){
        this.firstName = "Gus";
        this.score = 100.0;
    }
    //Parameterized constructor for the MyStudent class
    public MyStudent(String firstName, Double score){
        this.score = score;
        this.firstName = firstName;
    }
    //toString to format the printed items in the list
    @Override
    public String toString() {
        return String.format("%s, %.2f", firstName, score);
    }
}
