package Q_LE2;
import java.util.*;
import java.util.Scanner;
public class GenericAndArrays_Ghasan {
    //MyHeader method
    public static void MyHeader(int header) {
        System.out.println("===================================================================");
        System.out.println("Lab Exercise " + header + "-Q" + header);
        System.out.println("Prepared By: Ghasan Mahfoud");
        System.out.println("Student Number: 251280405");
        System.out.println("Goal Of This Exercise: Checking Code-Execution Time!");
        System.out.println("===================================================================");
    }
    //MyFooter method
    public static void MyFooter(int footer) {
        // \n to ensure the footer appears after the output
        System.out.println("\n===================================================================");
        System.out.println("Completion of Lab Exercise " + footer + "-Q" + footer + " is successful!");
        System.out.println("Signing off - Gus");
        System.out.println("===================================================================");
    }
    public static void main(String[] args) {
        //Calling MyHeader
        MyHeader(2);
        //Defining an int and scanner object for future use
        int i2 = 0;
        int year = 0;
        Scanner scan = new Scanner(System.in);
        //Defining 2 ArrayLists and adding to them
        ArrayList<Integer> YOStudy = new ArrayList(Arrays.asList(2,3,4,3,2,2));
        ArrayList<String> names = new ArrayList(Arrays.asList("Harry", "Lavender", "Ron", "Hermione", "Luna", "Vincent"));
        //Creates a Pair type reference array
        Pair[] pairArray = new Pair[YOStudy.size()];

        //Assigning the year and name to the new array
        for (Integer y : YOStudy) {
            String name = names.get(i2);
            pairArray[i2] = new Pair(y, name);
            i2++;
        }
        //Boolean expression to exit the while-loop
        boolean t = true;
        while (t) {
            //Try-Catch expression
            try {
                //Asking for user input and saving it to an int-type variable called 'a'
                System.out.println("What academic year would you like to search from: ");
                year = scan.nextInt();
                //Conditional while-loop to ensure the user inputs either 2, 3, or 4
                while (year != 2 && year != 3 && year != 4) {
                    System.out.println("That academic year is not valid, please choose from either 2, 3 or 4: ");
                    year = scan.nextInt();
                }
                //Iterates through the pairArray at the given year input and adds the corresponding names to a new ArrayList
                ArrayList<Object> list = new ArrayList();
                for (int i = 0; i < YOStudy.size(); i++) {
                    if (pairArray[i].getKey().equals(year)) {
                        list.add(pairArray[i].getValue());
                    }
                }
                //Prints the ArrayList
                System.out.println("Found " + list.size() + " leader(s) from year " + year + ".\n Here is the list:");
                System.out.println(list);
                //Catch exception in case a user inputs a non-int value
            } catch (Exception ex) {
                System.out.println("That is not a valid input! The input must be an integer value. \n" + ex);
            }
            //Asks the user if they want to search for more leaders
            System.out.println("Would you like to search for any more leaders? Type Y for yes, and N for no: ");
            if (scan.next().compareTo("N") == 0)
                t = false;
        }
        //MyFooter method
        MyFooter(2);
    }
}