import java.util.ArrayDeque;
import java.util.Collection;

public class Boarding {

}
