import java.util.*;
public class Passenger {
    private boolean assistance;
    private boolean children;
    private String name;

    public Passenger(boolean a, boolean c, String n) {
        this.assistance = a;
        this.children = c;
        this.name = n;
    }

    public String getName() {
        return name;
    }
    public boolean isAssistance(){
        return assistance;
    }
    public boolean isChildren(){
        return children;
    }

}

