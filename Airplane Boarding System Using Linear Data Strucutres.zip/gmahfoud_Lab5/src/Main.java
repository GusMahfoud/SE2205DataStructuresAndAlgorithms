import java.util.*;
public class Main {
    //MyHeader method
    public static void MyHeader(int labE_number, int q_number){
        System.out.println("===================================================================");
        System.out.println("Lab Exercise " + labE_number + "-Q" + q_number);
        System.out.println("Prepared By: Ghasan Mahfoud");
        System.out.println("Student Number: 251280405");
        System.out.println("Goal Of This Exercise: Creating a boarding and disembarking process for a plane!");
        System.out.println("===================================================================");
    }
    //MyFooter method
    public static void MyFooter(int labE_number, int q_number){
        // \n to ensure the footer appears after the output
        System.out.println("\n===================================================================");
        System.out.println("Completion of Lab Exercise " + labE_number + "-Q" + q_number + " is successful!");
        System.out.println("Signing off - Gus");
        System.out.println("===================================================================");
    }
    public static void main(String[] args) {
        /*
        The boarding portion of my code is designed using ArrayLists and ArrayDeque. Before I begin explaining why I chose these structures, I want to describe
        the structure of my boarding process. My boarding process uses a FIFO structure to board and disembark the plane. This is because FIFO allows for
        priority assignment without having to reorganize my data structure to adapt to the random inputs that occur when people buy plane tickets. For example,
        I can not assume all passengers with assistance will buy the first plane tickets for the front of the plane, then followed by those with children, then everyone else.
        This also means that I did not allow people to choose their seats. This is because with an undetermined number of people who could require assistance or could have children,
        I can't waste time or space restructuring the plane seats when the last person who buys a ticket needs to sit at the front because they require assistance and there are only seats available at the back.
        Now that I have established how my boarding process is structured, I can now explain why I used the data structures I did.
        I used an ArrayList due to their O(1) time complexity for inserting elements into the rear of the array and for finding elements at specific indices. I knew I would
        not have to restructure the ArrayList since there are always a predetermined number of seats on a plane and I would not have to add in between elements due to the way my boarding
        process is structured. I used an ArrayDeque in order to prep each ArrayList for the FIFO boarding and disembarking process, as an ArrayDeque has O(1) addition and removal using .add() and .poll().
        While it's similar to a regular Queue, and ArrayDeque provides the benefit of having no memory overhead due to the addition of node reference objects for each element.
        The time complexity overall is O(n) and the space complexity is O(1) (no additional spots requires outside the array sizes themselves).
        */
        //Creating the PlaneCreation reference object.
        PlaneCreation plane = new PlaneCreation();
        //Scanner reference object.
        Scanner scanner = new Scanner(System.in);
        //Creating the 2 data structures required for the boarding and graphical display.
        List<Passenger> passengers = new ArrayList<>(21);
        ArrayDeque<Integer> seating = new ArrayDeque<>(21);
        //Creation of support variables
        boolean passenger = true;
        boolean needsAssistance;
        boolean hasChildren;
        int count = 0;
        int count2 = 0;
        int count3 = 1;
        //MyHeader
        MyHeader(5, 1);
        //Displaying the initial plane pattern
        plane.displayPattern();
        //While-loop with time complexity O(n)
        while (passenger) {
            //While the number of passengers on the plane are less than or equal to 20
            if (count <= 20) {
                //Gets the passengers name
                System.out.print("What is your name: ");
                String name = scanner.nextLine();
                //Character checking to ensure the user inputs an actual name.
                //Time complexity of the while-loop is O(1) because it is based on user input.
                while (!name.matches("[a-zA-Z]+")) {
                    System.out.println("Invalid input. Please enter only letters:");
                    name = scanner.nextLine();
                }

                //Asking the user if they require special assistance
                System.out.println("Do you require special assistance (y or n): ");
                String ans = scanner.nextLine().trim().toLowerCase();
                //Time complexity of the while-loop is O(1) because it is based on user input.
                while (true) {
                    if (ans.equals("y")) {
                        needsAssistance = true;
                        break;
                    } else if (ans.equals("n")) {
                        needsAssistance = false;
                        break;
                    } else {
                        System.out.println("That is not a valid input. Please try again.");
                    }
                    ans = scanner.nextLine().trim().toLowerCase();
                }

                //Asking the user if they have children
                System.out.println("Do you have any children (y or n): ");
                ans = scanner.nextLine().trim().toLowerCase();
                //Time complexity of the while-loop is O(1) because it is based on user input.
                while (true) {
                    if (ans.equals("y")) {
                        hasChildren = true;
                        break;
                    } else if (ans.equals("n")) {
                        hasChildren = false;
                        break;
                    } else {
                        System.out.println("That is not a valid input. Please try again.");
                    }
                    ans = scanner.nextLine().trim().toLowerCase();
                }

                //Creating a passenger object using the Passenger class and adding it to the 'passengers' ArrayList.
                //Time complexity: O(1)
                passengers.add(new Passenger(needsAssistance, hasChildren, name));
                //Checking if there are any more passengers to add.
                System.out.println("Are there any more passengers left to add?");
                ans = scanner.nextLine().trim().toLowerCase();
                //Time complexity of the while-loop is O(1) because it is based on user input.
                while (true) {
                    if (ans.equals("y")) {
                        count ++;
                        break;
                    } else if (ans.equals("n")) {
                        passenger = false;
                        break;
                    } else {
                        System.out.println("That is not a valid input. Please try again.");
                    }
                    ans = scanner.nextLine().trim().toLowerCase();
                }
            } else { //If the plane is full, we stop adding onto the plane and the plane begins boarding.
                System.out.println("No more passengers can be added to the plane, the plane will now board and take off.");
                break;
            }
        }

        //Creating a new Deque to board passengers based on priority using the boardPassengers method from the Board class.
        Deque<String> boardingQueue = Board.boardPassengers(passengers);

        //Boarding process with time complexity O(n)
        while (!boardingQueue.isEmpty()) {
            System.out.println("Boarding passenger: " + boardingQueue.poll());
            count2 += 1;
            seating.add(count2);
        }
        //All the code after this point is used for graphical design and therefore isn't included in the marking (based on a conversation with Mr. Rahman).
        //But, I will still mention the time complexities for the process.
        //While-loop with time complexity O(n) to assign the plane positions.
        while (!seating.isEmpty()){
            plane.takePosition(seating.removeFirst());
        }
        //Printing the seats that are boarded.
        plane.displayPattern2();
        //Disembarking the plane based on FIFO priority.
        System.out.println("Disembarking based on FIFO priority...");
        //While-loop with time complexity O(n) to visually show the FIFO disembarking process.
        while (plane.hasNext()){
            plane.removePosition(count3);
            count3 += 1;
            plane.displayPattern2();
        }
        System.out.println("There is no one left on the plane.");
        MyFooter(5,1);
    }
}