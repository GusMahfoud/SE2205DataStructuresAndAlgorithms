public class PlaneCreation {
    /*
    The 'PlaneCreation' class is used for graphical design only, therefore time and space complexities were not taken into account and will not be described.
    */
    //The total number of positions
    private int posTot = 20;
    //Used in the hasNext() class.
    private boolean next = false;
    //Array to keep track of taken positions
    private boolean[] takenPos = new boolean[posTot];
    //Marks the positions as taken
    public void takePosition(int position) {
        if (position >= 0 && position < takenPos.length + 1) {
            takenPos[position-1] = true;
        }
    }
    //Removes positions from the plane
    public void removePosition(int position){
        if (position >= 0 && position < takenPos.length + 1){
            takenPos[position-1] = false;
        }
    }
    //Checks if the plane has a passenger
    public boolean hasNext(){
        for (boolean takenPo : takenPos) {
            if (takenPo) {
                next = true;
                break;
            } else {
                next = false;
            }
        }
        return next;
    }

    //Creates the initial plane pattern
    public void displayPattern() {
        System.out.println("==================================================================");
        // Display odd numbers
        for (int i = 0; i < posTot; i += 2) { // Increment by 2 to skip to the next odd number
            if (i < 10){
                System.out.print((i + 1) + "      ");
            } else {
                System.out.print((i+1) + "     ");
            }
        }
        System.out.println(); // New line after odd numbers

        // Display even numbers
        for (int i = 1; i < posTot; i += 2) { // Increment by 2 to skip to the next even number
            if (i < 9){
                System.out.print((i + 1) + "      ");
            } else {
                System.out.print((i+1) + "     ");
            }
        }
        System.out.println("\n==================================================================");
    }
    //Second plane pattern to display the onboarding and disembarking process.
    public void displayPattern2() {
        System.out.println("==================================================================");
        // Display odd numbers
        for (int i = 0; i < posTot; i += 2) { // Increment by 2 to skip to the next odd number
            if (takenPos[i]) {
                if (i < 10){
                    System.out.print((i + 1) + "      ");
                } else {
                    System.out.print((i + 1) + "     ");
                }
            } else {
                System.out.print("       ");
            }
        }
        System.out.println(); // New line after odd numbers

        // Display even numbers
        for (int i = 1; i < posTot; i += 2) { // Increment by 2 to skip to the next even number
            if (takenPos[i]) {
                if (i < 9){
                    System.out.print((i + 1) + "      ");
                } else {
                    System.out.print((i + 1) + "     ");
                }
            } else {
                System.out.print("       ");
            }
        }
        System.out.println("\n==================================================================");
    }
}
