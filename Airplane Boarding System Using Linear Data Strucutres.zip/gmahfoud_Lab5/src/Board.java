import java.util.*;
public class Board {
    //The boardPassengers method takes in a List of type Passenger and, using an ArrayDeque, organizes the passengers into seats based on their
    //accessibility and family requirements. The time complexity is O(n) and space complexity is O(1) (no additional spots requires outside the array size itself).
    public static Deque<String> boardPassengers(List<Passenger> passengers) {
        Deque<String> boardingQueue = new ArrayDeque<>();

        // Boarding priority: Needs assistance and has children. Assigned to the front of the plane
        for (Passenger p : passengers) {
            if (p.isAssistance() && p.isChildren()) {
                boardingQueue.addLast(p.getName());
            }
        }

        // Boarding priority: Needs assistance, no children. Assigned next.
        for (Passenger p : passengers) {
            if (p.isAssistance() && !p.isChildren()) {
                boardingQueue.addLast(p.getName());
            }
        }

        // Boarding priority: Has children, no assistance. Assigned next.
        for (Passenger p : passengers) {
            if (!p.isAssistance() && p.isChildren()) {
                boardingQueue.addLast(p.getName());
            }
        }

        // Boarding priority: No assistance, no children. Assigned last.
        for (Passenger p : passengers) {
            if (!p.isAssistance() && !p.isChildren()) {
                boardingQueue.addLast(p.getName());
            }
        }
        return boardingQueue;
    }
}
