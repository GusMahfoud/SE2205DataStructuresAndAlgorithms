package LE7Q1;
public class GusValueEntry {
    //Variable declaration
    private Integer key;
    //No arg. and arg. constructor
    public GusValueEntry(){
        key = -1;
    }
    public GusValueEntry(Integer key){
        this.key = key;
    }
    //Getters and setters

    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }
}
