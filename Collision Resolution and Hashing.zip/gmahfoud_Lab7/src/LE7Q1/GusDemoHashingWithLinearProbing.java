package LE7Q1;
import java.util.*;
public class GusDemoHashingWithLinearProbing {
    //Variables
    public static int items;
    public static Scanner input = new Scanner(System.in);
    public static double lf;
    public static int tableCapacity;
    public static GusValueEntry[] hashTable;
    public static GusValueEntry[] workingHashTable;

    //MyHeader method
    public static void MyHeader(int labE_number, int q_number){
        System.out.println("===================================================================");
        System.out.println("Lab Exercise " + labE_number + "-Q" + q_number);
        System.out.println("Prepared By: Ghasan Mahfoud");
        System.out.println("Student Number: 251280405");
        System.out.println("Goal Of This Exercise: Practicing Hashing!");
        System.out.println("===================================================================");
    }
    //MyFooter method
    public static void MyFooter(int labe_number, int q_number){
        // \n to ensure the footer appears after the output
        System.out.println("\n===================================================================");
        System.out.println("Completion of Lab Exercise " + labe_number + "-Q" + q_number + " is successful!");
        System.out.println("Signing off - Gus");
        System.out.println("===================================================================");
    }

    //Linear Probing method
    public static void addValueLinearProbing(Integer key){
        int index;
        //Checking and fixing negative index pos.
        if (key < 0) {
            index = key % tableCapacity;
            if (index != 0){
                index = index + tableCapacity;
            }
        } else {
            index = key % tableCapacity;
        }

        // Continue probing until an empty slot is found.
        while (hashTable[index].getKey() != -1 && !hashTable[index].getKey().equals(-111)) {
            index = (index + 1) % tableCapacity; // Wrap around using modulo.
        }

        // Place the new key in the found empty slot.
        hashTable[index] = new GusValueEntry(key);
    }

    //since in hashing, the prime number has to be greater than 2, we can
    //discard 2; 0 and 1 are not prime numbers by definition
    public static int checkPrime(int n) {
        int m = n / 2;//we just need to check half of the n factors
        for (int i = 3; i <= m; i++) {
            if (n % i == 0) {//if n is not a prime number
                i = 2; //reset i to 2 so that it is incremented to 3 in the for header
                n++;//next n value
                m = n / 2;//we just need to check half of the n factors
            }
        }
        return n;
    }//end of checkPrime()

    //Removal using linear probing
    public static void removeValueLinearProbe(Integer key) {
        //Index checking if index is negative
        int temp;
        if (key < 0) {
            temp = key % tableCapacity;
            if (temp != 0){
                temp = temp + tableCapacity;
            }
        } else {
            temp = key % tableCapacity;
        }


        //Removal process
        for (int i = 0; i < tableCapacity; i++) {
            // Check if the current slot is null, which means the key is not in the table
            if (/*hashTable[temp] == null*/ hashTable[temp].getKey() == -1) {
                System.out.println(key + " is not found!");
                break;
            }
            // Check if the current slot has the key we want to remove
            if (hashTable[temp].getKey().equals(key)) {
                System.out.println(hashTable[temp].getKey() + " is found and removed! ");
                hashTable[temp].setKey(-111); // Mark as removed with -111 (Available)
                return; // Exit after removing the key
            }
            temp = (temp + 1) % tableCapacity; // Probe to the next index
        }
    }
    //Printing the hash table
    public static void printHashTable() {
        System.out.print("The Current Hash-Table: [");
        //For loop that checks for null, available, or set positions and prints based on the result.
        for (int i = 0; i < hashTable.length; i++) {
            if (hashTable[i].getKey() == -1) {
                System.out.print("null"); // For null slots
            } else if (hashTable == null) {
                System.out.print("null");
            } else if (hashTable[i].getKey() == -111) {
                System.out.print("Available"); // For slots marked as available
            } else {
                System.out.print(hashTable[i].getKey()); // For slots with actual keys
            }
            if (i < hashTable.length - 1) {
                System.out.print(", "); // Separator between slots
            }
        }
        System.out.println("]");
    }

    //Rehashing with Linear Probing method
    public static void rehashingWithLinearProbe() {
        System.out.println("Rehashing the table...");
        //Creates a new table capacity using the check prime method and adding that capacity to the workingHashTable
        int newTableCapacity = checkPrime(tableCapacity * 2);
        workingHashTable = new GusValueEntry[newTableCapacity];
        //Filling the workingHashTable with null (-1) elements.
        for (int i = 0; i < newTableCapacity; i++) {
            workingHashTable[i] = new GusValueEntry();
        }

        // Rehash each entry from the old table
        for (GusValueEntry entry : hashTable) {
            // Skip null and 'available' slots
            if (entry.getKey() != -1 && !entry.getKey().equals(-111)) {
                int key = entry.getKey();
                int hash;
                if (key < 0) {
                    hash = key % newTableCapacity;
                    if (hash < 0) {
                        hash = hash + newTableCapacity;
                    }
                } else {
                    hash = key % newTableCapacity;
                }
                // Find the next available slot in the new hash table
                while (workingHashTable[hash].getKey() != -1 && !workingHashTable[hash].getKey().equals(-111)) {
                    hash = (hash + 1) % newTableCapacity; // Wrap around using modulo.
                }

                // Create a new entry and insert it into the new hash table
                workingHashTable[hash] = new GusValueEntry(key);
            }
        }

        hashTable = workingHashTable; // Replace the old table with the new table
        tableCapacity = newTableCapacity; // Update the table capacity
        System.out.println("The rehashed table capacity is: " + tableCapacity);
        printHashTable();
    }

    public static void main(String[] args) {
        MyHeader(7,1);
        //Prompting user for table capacity, item count and load factor.
        System.out.println("Let's decide on the initial table capacity based on the load factor and dataset size");
        System.out.println("How many data items: ");
        items = input.nextInt();
        System.out.println("What is the load factor (Recommended: <= 0.5): ");
        lf = input.nextDouble();
        //Creating the table capacity based on the method described in the slides.
        tableCapacity = checkPrime((int)Math.ceil(items / lf));
        System.out.println("The minimum required table capacity would be: " + tableCapacity);
        hashTable = new GusValueEntry[tableCapacity];
        //Filling hashtable with null elements.
        for (int i = 0; i < tableCapacity; i++) {
            hashTable[i] = new GusValueEntry();
        }
        //Recieving item input from the user and adding them to the hash table using the add by linear probing method.
        for (int i = 0; i < items; i++) {
            System.out.println("Enter item " + (i + 1) + ": ");
            int item = input.nextInt();
            addValueLinearProbing(item);
        }

        //Printing the hash table
        printHashTable();
        //Removing 2 values and then adding one by their respective methods.
        System.out.println("Lets remove two values from the table and then add one...");
        System.out.println("Enter a value you want to remove: ");
        int item = input.nextInt();
        removeValueLinearProbe(item);
        printHashTable();
        System.out.println("Enter a value you want to remove: ");
        item = input.nextInt();
        removeValueLinearProbe(item);
        printHashTable();
        System.out.println("Enter a value you want to add: ");
        item = input.nextInt();
        addValueLinearProbing(item);
        printHashTable();

        //Rehashing the table using the rehashing method.
        rehashingWithLinearProbe();
        MyFooter(7, 1);
    }
}
