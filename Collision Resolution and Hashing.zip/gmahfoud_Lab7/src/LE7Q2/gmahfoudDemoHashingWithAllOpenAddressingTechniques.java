package LE7Q2;
import LE7Q1.*; //this will import classes from the Q1 package
import static LE7Q1.GusDemoHashingWithLinearProbing.*; //this will import all the static fields and methods from the driver class of the Q1 package
public class gmahfoudDemoHashingWithAllOpenAddressingTechniques {
    //MyHeader method
    public static void MyHeader(int labE_number, int q_number){
        System.out.println("===================================================================");
        System.out.println("Lab Exercise " + labE_number + "-Q" + q_number);
        System.out.println("Prepared By: Ghasan Mahfoud");
        System.out.println("Student Number: 251280405");
        System.out.println("Goal Of This Exercise: Practicing More Hashing!");
        System.out.println("===================================================================");
    }
    //MyFooter method
    public static void MyFooter(int labe_number, int q_number){
        // \n to ensure the footer appears after the output
        System.out.println("\n===================================================================");
        System.out.println("Completion of Lab Exercise " + labe_number + "-Q" + q_number + " is successful!");
        System.out.println("Signing off - Gus");
        System.out.println("===================================================================");
    }
    //Adding through double hashing
    public static void addValueDoubleHashing(Integer key){
        //Creation of h1
        int h1;
        h1 = key % tableCapacity;
        //Finding q using helper method
        int q = thePrimeNumberForSecondHashFunction(tableCapacity);
        //Finding h2 using q
        int h2 = q - (key % q);

        //Adding to hashtable based on double hashing method in slides.
        if (hashTable[h1].getKey() == -1){
            hashTable[h1] = new GusValueEntry(key);
        } else {
            for (int i = 0; i < tableCapacity; i++){
                int value = hashTable[(h1 + (h2 * i)) % tableCapacity].getKey();
                //If a null space is found, add to the table, if not, keep searching.
                if (value == -1){
                    hashTable[(h1 + (h2*i)) % tableCapacity] = new GusValueEntry(key);
                    break;
                }
            }
        }
    }
    //Adding through quadratic probing
    public static void addValueQuadraticProbing(Integer key){
        //Boolean checker and a temp variable to use as to not mess with the key value
        boolean check = false;
        int temp = key;
        //Condition in case the key < 0
        while (temp < 0){
            temp = temp + tableCapacity;
        }

        // Continue probing until an empty slot is found.
        for (int i = 0; i < tableCapacity; i++) {
            int value = (temp + (i*i)) % tableCapacity;
            if (hashTable[value].getKey() == -1){
                check = true;
                hashTable[value] = new GusValueEntry(key);
                break;
            }
        }
        if (!check){
            System.out.println("Probing failed! Use a load factor of 0.5 or less. Goodbye!");
        }
    }
    //Print array method similar to the printarray from Q1
    public static void printArray(Integer[] array){
        System.out.print("The Given Dataset: [");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            if (i < array.length - 1) {
                System.out.print(", "); // Separator between slots
            }
        }
        System.out.println("]");
    }
    //Empty hash table method
    public static void emptyHashTable(){
        //Replacing each value in the table with null spots
        for (int i = 0; i < tableCapacity; i++) {
            hashTable[i] = new GusValueEntry();
        }
    }
    //Prime number checker
    public static int thePrimeNumberForSecondHashFunction(int tc){
        int p = tc - 1;

        while(true){
            if (isPrime(p)){
                return p;
            }
            p--;
        }
    }
    //Helper method for 'thePrimeNumberForSecondHashFunction'
    public static boolean isPrime(int a){
        if (a < 2){
            return false;
        }
        for (int i = 2; i < a/2; i++){
            if (a % i == 0){
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        //Similar opening to Q1 but with a predetermined array
        MyHeader(7,2);
        System.out.println("Let's demonstrate our understanding on all open addressing techniques...");
        System.out.println("How many data items: ");
        items = input.nextInt();
        System.out.println("What is the load factor (Recommended: <= 0.5): ");
        lf = input.nextDouble();
        tableCapacity = checkPrime((int)Math.ceil(items / lf));
        System.out.println("The minimum required table capacity would be: " + tableCapacity);
        hashTable = new GusValueEntry[tableCapacity];
        for (int i = 0; i < tableCapacity; i++) {
            hashTable[i] = new GusValueEntry();
        }
        Integer[] a = {-11, 22, -33, -44, 55};
        printArray(a);
        System.out.println("Let's enter each data item from the above to the hash table: ");
        //Emptying the hashtable
        emptyHashTable();
        System.out.println("Adding data - linear probing resolves collision");
        //Add each value using linear probing from q1
        for (int i = 0; i < a.length; i ++) {
            addValueLinearProbing(a[i]);
        }
        printHashTable();
        //Emptying the hashtable
        emptyHashTable();
        System.out.println("Adding data - quadratic probing resolves collision");
        //Add each value using quadratic probing method
        for (int i = 0; i < a.length; i ++) {
            addValueQuadraticProbing(a[i]);
        }
        printHashTable();
        //Emptying the hashtable
        emptyHashTable();
        System.out.println("Adding data - double-hashing resolves collision");
        //Add each value using double hashing method
        for (int i = 0; i < a.length; i ++) {
            addValueDoubleHashing(a[i]);
        }
        //Printing the q value for double hashing
        System.out.println("The q value for double hashing is: " + thePrimeNumberForSecondHashFunction(tableCapacity));
        printHashTable();
        MyFooter(7,2);
    }
}
