package LA3Q1;
//Import the Array library
import java.util.Arrays;

public class GusArray extends Pair {
    //Create a Pair[] type reference variable
    private Pair[] testArray;
    //Constructor
    public GusArray(){
        testArray = new Pair[0];
    }
    //Getter helper method
    public int getSize(){
        return testArray.length;
    }
    //Remove from last index method
    public Pair removeFromLastIndex(){
        //Assigning a Pair type array to the last element in the test array
        Pair removed = testArray[getSize()-1];
        //Creating a new empty array to be used for copying
        Pair[] newArray = new Pair[getSize()-1];
        //Copying old elements of testarray into new elements of newarray
        System.arraycopy(testArray, 0, newArray, 0, newArray.length);
        //Assigning testarray = newarray
        testArray = newArray;
        newArray = null;
        //Return the removed index
        return removed;
    }
    //Remove from first index method
    public Pair removeFromFirstIndex(){
        //Assigning a pair type variable to the first item of the array
        Pair removed = testArray[0];
        //Creating a new empty array to be used for copying
        Pair[] newArray = new Pair[getSize()-1];
        //Copying the array elements from testarray into newarray
        System.arraycopy(testArray, 1, newArray, 0, newArray.length);
        //Assinging testarray = newarray
        testArray = newArray;
        newArray = null;
        //Returning the removed index
        return removed;
    }
    //Add at last index method
    public void addAtLastIndex(Pair x){
        //Creating a new empty array to be used for copying
        Pair[] newArray = new Pair[getSize()+1];
        //Copying the array elements from testarray into newarray
        System.arraycopy(testArray, 0, newArray, 0, getSize());
        //Adding the new element to the new array
        newArray[newArray.length - 1] = x;
        //Assinging testarray = newarray
        testArray = newArray;
        newArray = null;
    }
    //Overriding the toString method
    @Override
    public String toString(){
        return Arrays.toString(testArray);
    }
}
