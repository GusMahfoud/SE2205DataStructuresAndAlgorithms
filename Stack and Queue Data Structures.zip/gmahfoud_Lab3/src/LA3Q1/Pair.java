package LA3Q1;

public class Pair <Y, N> {
    //Variable declaration
    private Y key;
    private N value;
    //Empty and filled constructors
    public Pair (){}
    public Pair(Y key, N value){
        this.key = key;
        this.value = value;
    }
    //Overriding the toString method
    @Override
    public String toString(){
        return "[YR: " + this.key + ", NM: " + this.value + "]";
    }
}
