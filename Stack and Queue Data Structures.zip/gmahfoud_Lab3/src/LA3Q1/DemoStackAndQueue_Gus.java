package LA3Q1;
//Importing the java scanner
import java.util.Scanner;

public class DemoStackAndQueue_Gus extends GusArray {
    //MyHeader method
    public static void MyHeader(int header){
        System.out.println("===================================================================");
        System.out.println("Lab Exercise " + header + "-Q" + header);
        System.out.println("Prepared By: Ghasan Mahfoud");
        System.out.println("Student Number: 251280405");
        System.out.println("Goal Of This Exercise: Iterating through and altering a Stack!");
        System.out.println("===================================================================");
    }

    //MyFooter method
    public static void MyFooter(int footer){
    //\n to ensure the footer appears after the output
        System.out.println("\n===================================================================");
        System.out.println("Completion of Lab Exercise " + footer + "-Q" + footer + " is successful!");
        System.out.println("Signing off - Gus");
        System.out.println("===================================================================");
    }

    //Stack demo method
    public static void stackDemo(GusArray array){
        //Scanner object
        Scanner input = new Scanner(System.in);
        //Boolean variable for the while loop and variable creation
        boolean continueLoop = true;
        int year;
        String name;
        System.out.printf("\nYou have an empty stack: %s\n", array);
        while (continueLoop) {
            //Asking for users choice
            System.out.println("\na: Push" + "\nb: Pop" + "\nc: Exit" + "\nEnter your choice: ");
            char ans = input.next().charAt(0);
            //Conditional if statement to ensure the user inputs a b or c.
            if (ans == 'a' || ans == 'b' || ans == 'c'){
                if (ans == 'a'){
                    //Pushing items to the stack using the addAtLastIndex method
                    System.out.println("Lets push a data-item into the stack...");
                    System.out.println("Enter the year of study: ");
                    year = input.nextInt();
                    System.out.println("Enter the name: ");
                    name = input.next();
                    Pair combo = new Pair(year, name);
                    array.addAtLastIndex(combo);
                    //Printing the current stack
                    System.out.printf("\nThe current stack: %s", array);
                } else if (ans == 'b'){
                    //Popping a data item using removeFromLastIndex
                    System.out.println("Lets pop a data item...");
                    //Conditional if statement if the array is empty
                    if (array.getSize() == 0){
                        System.out.println("FYI: The stack is empty");
                        break;
                    }
                    Pair lastItem = array.removeFromLastIndex();
                    System.out.println(lastItem +"\nis removed.");
                    System.out.printf("\nThe current stack: %s", array);
                } else {
                    //Exiting the menu if the letter selected was c
                    continueLoop = false;
                }
            } else {
                System.out.println("That input is not valid!");
            }
        }
    }
    //Queue demo method
    public static void queueDemo(GusArray array){
        Scanner input = new Scanner(System.in);
        boolean continueLoop = true;
        int year;
        String name;
        System.out.printf("\nYou have an empty stack: %s", array.toString());
        while (continueLoop) {
            //Asking user if they want to enqueue, dequeue or exit
            System.out.println("\na: Enqueue" + "\nb: Dequeue" + "\nc: Exit" + "\nEnter your choice: ");
            char ans = input.next().charAt(0);
            //Conditional if statement to make sure the user inputs a b or c.
            if (ans == 'a' || ans == 'b' || ans == 'c'){
                //Enqueue using addAtlastIndex
                if (ans == 'a') {
                    System.out.println("Enter the year of study: ");
                    year = input.nextInt();
                    System.out.println("Enter the name: ");
                    name = input.next();
                    Pair combo = new Pair(year, name);
                    array.addAtLastIndex(combo);
                    System.out.printf("The current stack: %s", array);
                } else if (ans == 'b') {
                    //Dequeue using removeFromFirstIndex
                    if (array.getSize() == 0) {
                        System.out.println("FYI: The stack is empty");
                        break;
                    }
                    Pair firstItem = array.removeFromFirstIndex();
                    System.out.println(firstItem +"\nis removed.");
                    System.out.printf("\nThe current stack: %s", array);
                } else {
                    continueLoop = false;
                }
            } else {
                System.out.println("That input is not valid!");
            }
        }
    }

    public static void main(String[] args) {
        //Creating an instance of GusArray
        GusArray out = new GusArray();
        boolean run = true;
        //Header method
        MyHeader(3);
        while (run){
            //Asking the user which of the 3 inputs they would want to do
            Scanner input = new Scanner(System.in);
            System.out.println("Choose one of the three options: ");
            System.out.println("1: Stack" + "\n2: Queue" + "\n3: Exit");
            int ans = input.nextInt();
            if (ans == 1) {
                stackDemo(out);
            } else if (ans == 2) {
                queueDemo(out);
            } else {
                run = false;
            }
        }
        //MyFooter method
        MyFooter(3);
    }
}
