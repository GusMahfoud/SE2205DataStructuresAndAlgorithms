package LE6Q1;

import java.util.*;

public class GusTestingSortingMethods {
    //MyHeader method
    public static void MyHeader(int labE_number, int q_number){
        System.out.println("===================================================================");
        System.out.println("Lab Exercise " + labE_number + "-Q" + q_number);
        System.out.println("Prepared By: Ghasan Mahfoud");
        System.out.println("Student Number: 251280405");
        System.out.println("Goal Of This Exercise: Testing Sorting Algorithms!");
        System.out.println("===================================================================");
    }
    //MyFooter method
    public static void MyFooter(int labe_number, int q_number){
        // \n to ensure the footer appears after the output
        System.out.println("\n===================================================================");
        System.out.println("Completion of Lab Exercise " + labe_number + "-Q" + q_number + " is successful!");
        System.out.println("Signing off - Gus");
        System.out.println("===================================================================");
    }
    //Selection sort algorithm
    public static <T extends Comparable <? super T>>long selectionSort (T [] a){
        long startTime = System.nanoTime();
        for (int i = 0; i < a.length; i ++){
            int minIndex = i;
            for (int j = i + 1; j < a.length; j++){
                if (a[j].compareTo(a[minIndex]) < 0){
                    minIndex = j;
                }
            }
            T temp = a[minIndex];
            a[minIndex] = a[i];
            a[i] = temp;
        }
        long endTime = System.nanoTime();
        return endTime - startTime;
    }
    public static < T extends Comparable <? super T >> long bubbleSort(T[] a){
        long startTime = System.nanoTime();
        boolean nextPassNeeded = true;
        for (int i = 1; i < a.length && nextPassNeeded; i++){
            nextPassNeeded = false;
            for (int j = 0; j < a.length - i; j++){
                T temp = a[j];
                a[j] = a[j+1];
                a[j+1] = temp;
                nextPassNeeded = true;
            }
        }
        long endTime = System.nanoTime();
        return endTime - startTime;
    }
    //Insertion sort algorithm
    public static < T extends Comparable <? super T >> long insertionSort(T[] a){
        long startTime = System.nanoTime();
        for (int i = 1; i < a.length; i ++){
            T key = a[i];
            int j = i-1;
            while (j >= 0 && a[j].compareTo(key) > 0) {
                a[j + 1] = a[j];
                j = j - 1;
            }
            a[j+1] = key;
        }
        long endTime = System.nanoTime();
        return endTime - startTime;
    }
    //Merge sort algorithm
    public static <T extends Comparable<? super T>> long mergeSort(T[] S){
        long startTime = System.nanoTime();
        int n = S.length;
        if (n > 2) {
            // divide
            int mid = n / 2;
            T[] S1 = Arrays.copyOfRange(S, 0, mid); // copy of first half
            T[] S2 = Arrays.copyOfRange(S, mid, n); // copy of second half
            // conquer (with recursion)
            mergeSort(S1); // sort copy of first half
            mergeSort(S2); // sort copy of second half
            // merge sorted halves back into original
            int i = 0, j = 0;
            while (i + j < S.length) {
                if (j == S2.length || (i < S1.length && S1[i].compareTo(S2[j]) < 0)) {
                    S[i + j] = S1[i++]; // copy ith element of S1 and increment i
                } else {
                    S[i + j] = S2[j++]; // copy jth element of S2 and increment j
                }
            }
        }
        long endTime = System.nanoTime();
        return endTime - startTime;
    }
    //Quicksort algorithm
    public static <T extends Comparable<? super T>> long quickSort(T[] s, int a, int b){
        long startTime = System.nanoTime();
        if (a >= b){
            return 0;
        }
        int left = a;
        int right = b - 1;
        T pivot = s[b];
        T temp;
        while (left <= right){
            while (s[left].compareTo(pivot) < 0){
                left++;
            }
            while (s[right].compareTo(pivot) > 0){
                right--;
            }
            if (left <= right){
                temp = s[left];
                s[left] = s[right];
                s[right] = temp;
                left++;
                right--;
            }
        }
        temp = s[left];
        s[left] = s[b];
        s[b] = temp;

        quickSort(s, a, left - 1);
        quickSort(s, left + 1, b);

        long endTime = System.nanoTime();
        return endTime - startTime;
    }
    //Bucket sort algorithm.
    public static long bucketSort(Integer[] a, int first, int last, int maxDigits){
        long startTime = System.nanoTime();
        //Since the radix is the length of the array, creating an equal number of buckets to the length of the array using Vector.
        //Assumption: positive integers only
        Vector<Integer>[] bucket = new Vector[10];
        //instantiate each bucket;
        for (int i = 0; i < 10; i++)
            bucket[i] = new Vector<>();
        for (int i = 0; i < maxDigits; i++) {
            //clear the Vector buckets
            for (int j = 0; j < 10; j++) {
                bucket[j].removeAllElements();
            }
            //Placing a[index] at end of bucket[digit]
            for (int index = first; index <= last; index++) {
                Integer digit = findDigit(a[index], i);
                bucket[digit].add(a[index]);
            }
            //placing all the buckets back into the array
            int index = 0;
            for (int m = 0; m < 10; m++) {
                for (int n = 0; n < bucket[m].size(); n++) {
                    a[index++] = bucket[m].get(n);
                }
            }
        }
        long endTime = System.nanoTime();
        return endTime - startTime;
    }

    //The following method extracts the ith digit from a decimal number which is used in the Bubble Sort method
    public static Integer findDigit(int number, int i) {
        int target = 0;
        for (int k = 0; k <= i; k++) {
            target = number % 10;
            number = number / 10;
        }
        return target;
    }

    public static void main(String[] args) {
        MyHeader(6, 1);
        int sz = 50000;
        int max = 13;
        int min = 93;
        Integer[] array = new Integer[sz];
        Integer[] barray = new Integer[sz];
        for (int i = 0; i < array.length; i++){
            array[i] = (int)(Math.random() * (max - min + 1) + min);
        }
        System.arraycopy(array, 0, barray, 0, barray.length);
        List<Integer> list1 = Arrays.asList(array);
        System.out.println("Testing te execution time of different sorting methods for sorting 50000 random numbers:");
        long startTime = System.nanoTime();
        Collections.sort(list1);
        long endTime = System.nanoTime();
        long finalTime = endTime - startTime;
        //System.out.println("The unsorted list: " + list1);
        System.out.printf("Collections sort time: %.2f milliseconds.\n", finalTime/1e6);
        //System.out.println("The sorted list using Collections' sort method: " + list1);
        System.out.println("");
        System.arraycopy(barray, 0, array, 0, array.length);
        //System.out.println("The unsorted list: " + list1);
        System.out.printf("My Selection sort time: %.2f milliseconds.\n", selectionSort(array)/1e6);
        //System.out.println("The sorted list using selection sort: " + list1);
        System.out.println("");
        System.arraycopy(barray, 0, array, 0, array.length);
        //System.out.println("The unsorted list: " + list1);
        System.out.printf("My Bubble sort time: %.2f milliseconds.\n", bubbleSort(array)/1e6);
        //System.out.println("The sorted list using bubble sort: " + list1);
        System.out.println("");
        System.arraycopy(barray, 0, array, 0, array.length);
        //System.out.println("The unsorted list: " + list1);
        System.out.printf("My Insertion sort time: %.2f milliseconds.\n", insertionSort(array)/1e6);
        //System.out.println("The sorted list using insertion sort: " + list1);
        System.out.println("");
        System.arraycopy(barray, 0, array, 0, array.length);
        //System.out.println("The unsorted list: " + list1);
        System.out.printf("My Merge sort time: %.2f milliseconds.\n", mergeSort(array)/1e6);
        //System.out.println("The sorted list using merge sort: " + list1);
        System.out.println("");
        System.arraycopy(barray, 0, array, 0, array.length);
        //System.out.println("The unsorted list: " + list1);
        System.out.printf("My Quick sort time: %.2f milliseconds.\n", quickSort(array, 0, array.length - 1)/1e6);
        //System.out.println("The sorted list using quick sort: " + list1);
        System.out.println("");
        System.arraycopy(barray, 0, array, 0, array.length);
        //System.out.println("The unsorted list: " + list1);
        System.out.printf("My Bucket sort time: %.2f milliseconds.\n", bucketSort(array, 0, array.length-1, 2)/1e6);
        //System.out.println("The sorted list using bucket sort: " + list1);
        MyFooter(6,1);
    }
}
