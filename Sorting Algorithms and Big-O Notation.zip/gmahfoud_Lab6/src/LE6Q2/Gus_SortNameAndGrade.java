package LE6Q2;
import java.util.*;
public class Gus_SortNameAndGrade {
    //MyHeader method
    public static void MyHeader(int labE_number, int q_number){
        System.out.println("===================================================================");
        System.out.println("Lab Exercise " + labE_number + "-Q" + q_number);
        System.out.println("Prepared By: Ghasan Mahfoud");
        System.out.println("Student Number: 251280405");
        System.out.println("Goal Of This Exercise: Testing Sorting Algorithms!");
        System.out.println("===================================================================");
    }
    //MyFooter method
    public static void MyFooter(int labe_number, int q_number){
        // \n to ensure the footer appears after the output
        System.out.println("\n===================================================================");
        System.out.println("Completion of Lab Exercise " + labe_number + "-Q" + q_number + " is successful!");
        System.out.println("Signing off - Gus");
        System.out.println("===================================================================");
    }

    // Entry point of the program
    public static void main(String[] args) {
        // Print header
        MyHeader(6,2);

        // Arrays holding first names, last names, and grades
        String[] fnArray = {"Hermione", "Ron", "Harry", "Luna", "Ginny", "Draco", "Dean", "Fred"};
        String[] lnArray = {"Granger", "Weasley", "Potter", "Lovegood", "Weasley", "Malfoy", "Thomas", "Weasley"};
        // Array to hold randomly generated grades between 60 and 85
        Integer[] grd = new Integer[fnArray.length];
        for (int i = 0; i < grd.length; i++){
            grd[i] = (int)(60 + Math.random()*26);
        }

        // Vector to hold StudentGrade objects
        Vector<StudentGrade> sg = new Vector<>();

        // Populate the vector with StudentGrade objects
        for (int i = 0; i < grd.length; i++){
            StudentGrade student = new StudentGrade(fnArray[i], lnArray[i], grd[i]);
            sg.add(student);
        }

        // Display the unsorted list of students
        System.out.println("The unsorted array ..............");
        System.out.println(sg + "\b");

        // Sort the vector based on grades (natural ordering)
        Collections.sort(sg);

        // Display the sorted list by grades
        System.out.println("Sorted by grades ..............");
        System.out.println(sg + "\b");

        // Copy the sorted vector into an array for further sorting
        StudentGrade[] array = new StudentGrade[fnArray.length];
        sg.copyInto(array);

        // Sort by first names using the custom insertionSort method
        insertionSort(array, 1);
        System.out.println("Sorted by first names ..............");
        printArray(array);

        // Sort by last names using the custom insertionSort method
        insertionSort(array, 2);
        System.out.println("Sorted by last names ..............");
        printArray(array);

        // Print footer
        MyFooter(6,2);
    }

    // Custom insertion sort method that sorts based on a key; 1 for first names, 2 for last names
    public static < T extends Comparable <? super T >> void insertionSort(StudentGrade[] a, Integer key){
        int i = 0;
        int j = 0;
        if (key == 1) {
            for (i = 1; i < a.length; i++) {
                StudentGrade helper = a[i];
                j = i - 1;
                while (j >= 0 && a[j].getFirstName().compareTo(helper.getFirstName()) > 0) {
                    a[j + 1] = a[j];
                    j = j - 1;
                }
                a[j + 1] = helper;
            }
        } else if (key == 2){
            for (i = 1; i < a.length; i++) {
                StudentGrade helper = a[i];
                j = i - 1;
                while (j >= 0 && a[j].getLastName().compareTo(helper.getLastName()) > 0) {
                    a[j + 1] = a[j];
                    j = j - 1;
                }
                a[j + 1] = helper;
            }
        }
    }

    // Method to print the array of StudentGrade objects
    public static void printArray(StudentGrade[] a){
        // Loop through each StudentGrade object and print using the custom toString method
        for (int i = 0; i < a.length; i++){
            System.out.print(a[i].toString());
        }
        System.out.println("\n");
    }
}
