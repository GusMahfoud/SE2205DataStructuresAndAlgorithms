package LE6Q2;

public class StudentGrade implements Comparable<StudentGrade>{
    // Private member variables to hold the first name, last name, and grade of a student
    private String firstName;
    private String lastName;
    private Integer grade;

    // Default constructor (no parameters)
    public StudentGrade(){}

    // Constructor with parameters to set the student's first name, last name, and grade
    public StudentGrade(String firstName, String lastName, int grade){
        this.firstName = firstName;
        this.lastName = lastName;
        this.grade = grade;
    }

    // Setter method for last name
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    // Setter method for first name
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    // Setter method for grade
    public void setGrade(int grade) {
        this.grade = grade;
    }

    // Getter method for last name
    public String getLastName() {
        return lastName;
    }

    // Getter method for first name
    public String getFirstName() {
        return firstName;
    }

    // Getter method for grade
    public int getGrade() {
        return grade;
    }

    // Overridden compareTo method from the Comparable interface to sort by grade
    @Override
    public int compareTo(StudentGrade s) {
        // Use Integer.compare to compare grades for natural ordering (ascending)
        return Integer.compare(this.grade, s.getGrade());
    }

    // Overridden toString method to format the output as "FirstName LastName : Grade"
    @Override
    public String toString(){
        // The backspace characters \b\b are an attempt to remove the comma and space from the Vector's default toString output
        // The newline character \n is used to ensure each student's info is printed on a new line
        return "\b\b" + getFirstName() + " " + getLastName() + " : " + getGrade() + "\n";
    }
}